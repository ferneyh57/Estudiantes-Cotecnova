<?php

require '../pdf.php';
require '../MySQL.php';

$pdf = new PDF ('P','mm','A4');
$mysql = new MySQL ();

$mysql = new MySQL;
                 
            $mysql->conectar();

            $consulta = $mysql ->efectuarConsulta("select tiendacotecnova.creditos.cre_fecha_hora_act,  tiendacotecnova.creditos.cre_est_doc_iden,  tiendacotecnova.creditos.cre_est_total_credito,  tiendacotecnova.creditos.cre_ven_doc_iden from tiendacotecnova.creditos");
            
            $titulo= 'Reporte creditos totales';
            $pdf->SetTitle($titulo);
            
//Generar tabla
$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();

//Header
$pdf->Cell(60,10,'hora - fecha',1,0,'C',0);
$pdf->Cell(45,10,'documento estu',1,0,'C',0);
$pdf->Cell(45,10,'totalcreditos',1,0,'C',0);
$pdf->Cell(40,10,'docum vendedor',1,1,'C');

$pdf->SetFont('Arial','',14);
while ($row = $consulta->fetch_assoc())
{
    $pdf->Cell(60,10, utf8_decode($row['cre_fecha_hora_act']),1,0,'C',0);
    $pdf->Cell(45,10, utf8_decode($row['cre_est_doc_iden']),1,0,'C',0);
    $pdf->Cell(45,10, utf8_decode($row['cre_est_total_credito']),1,0,'C',0);
    $pdf->Cell(40,10, utf8_decode($row['cre_ven_doc_iden']),1,1,'C',0);
    
}


$pdf->Output('creditos_totales.php','I');