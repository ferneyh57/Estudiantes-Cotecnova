<?php

require '../pdf.php';
require '../MySQL.php';

$pdf = new PDF ('P','mm','A4');
$mysql = new MySQL ();

$mysql = new MySQL;
                 
            $mysql->conectar();

            $consulta = $mysql ->efectuarConsulta("select tiendacotecnova.estudiantes.est_nombres,  tiendacotecnova.estudiantes.est_doc_iden,  tiendacotecnova.estudiantes.est_total_credito from tiendacotecnova.estudiantes");
            
            $titulo= 'Reporte creditos estudiantes';
            $pdf->SetTitle($titulo);
            
//Generar tabla
$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();

//Header
$pdf->Cell(60,10,'nombre',1,0,'C',0);
$pdf->Cell(45,10,'documento',1,0,'C',0);
$pdf->Cell(45,10,'totalcreditos',1,0,'C',0);

$pdf->SetFont('Arial','',14);
while ($row = $consulta->fetch_assoc())
{
    $pdf->Cell(60,10, utf8_decode($row['est_nombres']),1,0,'C',0);
    $pdf->Cell(45,10, utf8_decode($row['est_doc_iden']),1,0,'C',0);
    $pdf->Cell(45,10, utf8_decode($row['est_total_credito']),1,0,'C',0);
    
}


$pdf->Output('creditos_estudiantes.php','I');