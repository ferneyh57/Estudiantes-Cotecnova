<?php

require '../pdf.php';
require '../MySQL.php';

$pdf = new PDF ('P','mm','A4');
$mysql = new MySQL ();

$mysql = new MySQL;
                 
            $mysql->conectar();

            $consulta = $mysql ->efectuarConsulta("select tiendacotecnova.vendedores.ven_doc_iden,  tiendacotecnova.vendedores.ven_nombres from tiendacotecnova.vendedores");
            
            $titulo= 'Reporte creditos dados por vendedores';
            $pdf->SetTitle($titulo);
            
//Generar tabla
$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();

//Header
$pdf->Cell(60,10,'documento vendedor',1,0,'C',0);
$pdf->Cell(45,10,'nombre vendedor',1,0,'C',0);
$pdf->Cell(45,10,'totalcreditos',1,0,'C',0);
$pdf->Cell(40,10,'docum vendedor',1,1,'C');

$pdf->SetFont('Arial','',14);
while ($row = $consulta->fetch_assoc())
{
    $pdf->Cell(60,10, utf8_decode($row['ven_doc_iden']),1,0,'C',0);
    $pdf->Cell(45,10, utf8_decode($row['ven_nombres']),1,0,'C',0);
    
}


$pdf->Output('credito_vendedor.php','I');
